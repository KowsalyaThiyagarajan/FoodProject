package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.CustomerRegister;


// JpaRepository --> it is an interface , it will provide pre defined crud methods save,delete,update,get<EntityType,PrimaryKey Datatype>
public interface CustomerRegisterRepo extends JpaRepository<CustomerRegister,Integer>{

}
