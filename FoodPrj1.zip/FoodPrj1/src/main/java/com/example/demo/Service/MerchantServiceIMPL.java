package com.example.demo.Service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.MerchantDTO;
import com.example.demo.DTO.MerchantSaveDTO;
import com.example.demo.Exception.ResourceNotFound;
import com.example.demo.Model.Merchant;
import com.example.demo.Repository.MerchantRepo;

@Service
public class MerchantServiceIMPL implements MerchantService {
	@Autowired
	private MerchantRepo merchantRepo;

	@Override
	public String addMerchant(MerchantSaveDTO merchantSaveDTO) {
		Merchant  merchant=new  Merchant(0,  merchantSaveDTO.getFirstname(),merchantSaveDTO.getLastname(),merchantSaveDTO.getUsername(),merchantSaveDTO.getPassword(),merchantSaveDTO.getEmail(),merchantSaveDTO.getPhoneNo(),merchantSaveDTO.getRestaurantName(),merchantSaveDTO.getLocation());
		merchantRepo.save(merchant);
		return merchant.getFirstname();
	}

	@Override
	public List<MerchantDTO> getAllMerchant() {
		List<Merchant>getMerchant=merchantRepo.findAll();
		List<MerchantDTO>MerchantDTOList=new ArrayList<>();
		for(Merchant a:getMerchant)
		{
			MerchantDTO merchantDTO=new MerchantDTO(a.getRestaurantId(),a.getFirstname(),a.getLastname(),a.getUsername(),a.getPassword(),a.getEmail(),a.getPhoneNo(),a.getRestaurantName(),a.getLocation());
					
			MerchantDTOList.add(merchantDTO);
		}
		
		return MerchantDTOList;
	}


	@Override
	public boolean deleteMerchant(int id) {
		if(merchantRepo.existsById(id))
		{
			merchantRepo.deleteById(id);
		}
		else
		{
			System.out.println("Merchant ID is Not found..");
		}
			return true;
		}

	@Override
	public Merchant updateMerchant(Merchant merchant, int id) {
		Merchant existingMerchant=merchantRepo.findById(id).orElseThrow(()->new ResourceNotFound("Customer","Id","id"));
		existingMerchant.setFirstname(merchant.getFirstname());
		existingMerchant.setLastname(merchant.getLastname());
		existingMerchant.setUsername(merchant.getUsername());
		existingMerchant.setPassword(merchant.getPassword());
		existingMerchant.setEmail(merchant.getEmail());
		existingMerchant.setPhoneNo(merchant.getPhoneNo());
		existingMerchant.setRestaurantName(merchant.getRestaurantName());
		existingMerchant.setLocation(merchant.getLocation());
		
		merchantRepo.save(existingMerchant);
		
		return existingMerchant;
	}
}
