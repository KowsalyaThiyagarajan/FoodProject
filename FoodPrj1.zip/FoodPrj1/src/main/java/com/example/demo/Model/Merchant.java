package com.example.demo.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RestaurantDetails")
public class Merchant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int RestaurantId;
	@Column(name = "firstName")
	private String firstname;
	@Column(name = "lastName")
	private String lastname;
	@Column(name = "username")
	private String username;
	private String password;
	@Column(name = "Email")
	private String email;
	@Column(name = "PhoneNo")
	private String phoneNo;
	@Column(name="RestaurantName")
	private String RestaurantName;
	@Column(name = "location")
	private String location;
	
	public Merchant() {
		
	}

	public int getRestaurantId() {
		return RestaurantId;
	}

	public void setRestaurantId(int restaurantId) {
		RestaurantId = restaurantId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getRestaurantName() {
		return RestaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		RestaurantName = restaurantName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Merchant(int restaurantId, String firstname, String lastname, String username, String password, String email,
			String phoneNo, String restaurantName, String location) {
		super();
		RestaurantId = restaurantId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.email = email;
		this.phoneNo = phoneNo;
		this.RestaurantName = restaurantName;
		this.location = location;
	}

	@Override
	public String toString() {
		return "Merchant [RestaurantId=" + RestaurantId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", username=" + username + ", password=" + password + ", email=" + email + ", phoneNo=" + phoneNo
				+ ", RestaurantName=" + RestaurantName + ", location=" + location + "]";
	}
	
	
	
}
