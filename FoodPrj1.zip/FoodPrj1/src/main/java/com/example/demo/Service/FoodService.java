package com.example.demo.Service;

import com.example.demo.DTO.FoodDTO;
import com.example.demo.DTO.FoodSaveDTO;
import com.example.demo.Model.FoodList;

import java.util.*;

public interface FoodService {
	String addfood(FoodSaveDTO foodSaveDTO );
	List<FoodDTO>getAllFood();
	boolean deleteFood(int id);
	FoodList updateFood(FoodList food, int id);

}
