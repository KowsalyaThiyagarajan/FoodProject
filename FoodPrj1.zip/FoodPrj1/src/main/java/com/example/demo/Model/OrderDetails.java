package com.example.demo.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Order_Details")
public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Orderid")

	private int OrderId;
	@Column(name = "foodname")
	private String FoodName;
	@Column(name = "foodprice")
	private int foodprice;
	@Column(name = "foodimage")
	private String foodimage;
	@Column(name="Food_Quantity")
	private int foodQuantity;
	@Column(name="Total_Price")
	private int totalPrice;
	public OrderDetails() {
		super();
		
	}
	public int getOrderId() {
		return OrderId;
	}
	public void setOrderId(int orderId) {
		OrderId = orderId;
	}
	public String getFoodName() {
		return FoodName;
	}
	public void setFoodName(String foodName) {
		FoodName = foodName;
	}
	public int getFoodprice() {
		return foodprice;
	}
	public void setFoodprice(int foodprice) {
		this.foodprice = foodprice;
	}
	public String getFoodimage() {
		return foodimage;
	}
	public void setFoodimage(String foodimage) {
		this.foodimage = foodimage;
	}
	
	public int getFoodQuantity() {
		return foodQuantity;
	}
	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	

	public OrderDetails(int orderId, String foodName, int foodprice, String foodimage, int foodQuantity,
			int totalPrice) {
		super();
		OrderId = orderId;
		FoodName = foodName;
		this.foodprice = foodprice;
		this.foodimage = foodimage;
		this.foodQuantity = foodQuantity;
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "OrderDetails [OrderId=" + OrderId + ", FoodName=" + FoodName + ", foodprice=" + foodprice
				+ ", foodimage=" + foodimage + ", foodQuantity=" + foodQuantity + ", totalPrice=" + totalPrice + "]";
	}
	
}
