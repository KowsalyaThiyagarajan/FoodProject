import { FoodList } from './food-list';

describe('FoodList', () => {
  it('should create an instance', () => {
    expect(new FoodList()).toBeTruthy();
  });
});
