import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FoodlistService } from '../service/foodlist.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit{

  constructor(private foodListService : FoodlistService,private router : Router) { 
   
  }
  ngOnInit(): void{
    
  }
  
  userRoute(){
    this.router.navigate(['user'])
  }
  foodRoute(){
    this.router.navigate(['food'])
  }
  loginRoute(){
    this.router.navigate(['login'])
  }
};
