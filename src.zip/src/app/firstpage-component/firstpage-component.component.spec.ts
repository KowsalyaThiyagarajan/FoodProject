import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstpageComponentComponent } from './firstpage-component.component';

describe('FirstpageComponentComponent', () => {
  let component: FirstpageComponentComponent;
  let fixture: ComponentFixture<FirstpageComponentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FirstpageComponentComponent]
    });
    fixture = TestBed.createComponent(FirstpageComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
