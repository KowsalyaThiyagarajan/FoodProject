import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterService } from '../service/register.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent {
  login: FormGroup;
  notvalid: boolean = false;
  isRequired: boolean = false;
  constructor(private router: Router, private loginService: RegisterService, private loginForm: FormBuilder) {
    this.login = new FormGroup({
      username: new FormControl('', Validators.required),
    })
  }
  ngOnit() {

  }
  back() {
    this.router.navigate([''])
  }
  homeroute() {
    var userName = this.login.controls['username'].value
    if (userName != '' && userName != null && userName != undefined ) {
      this.loginService.checkUser(userName).subscribe((res:any) => {
console.log(res);
        if (res!='' && res[0]!=undefined) {
          this.router.navigate(['homepage']);
          if(userName == "Admin@123"){
            this.router.navigate(['adminHome']);
          }
        } 
        else {
          this.notvalid = true
        }
      })
    }
   
else{
  this.isRequired=true;
}
  }
  userCheck(searchValue: any) {
    this.isRequired = false;
    console.log(searchValue.data);
  }
}
//subscribe--> It will notify that observable datas