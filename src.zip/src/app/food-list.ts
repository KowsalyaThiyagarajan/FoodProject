export class FoodList {
    foodId!:number;
    foodName!:string;
    foodprice!:string;
    foodimage!:string;
}
