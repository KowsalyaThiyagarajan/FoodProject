import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FoodlistService } from '../service/foodlist.service';

@Component({
  selector: 'app-listfood',
  templateUrl: './listfood.component.html',
  styleUrls: ['./listfood.component.css']
})
export class ListfoodComponent implements OnInit{
  foodList=null;
  editFood: FormGroup;
  foodid:any;
alert:boolean=false;
  constructor(private foodListService : FoodlistService,private router : Router) { 
    this.getFoodList();
    this.editFood = new FormGroup({
      foodId: new FormControl(''),
      foodName: new FormControl(''),
      foodprice: new FormControl('')
    })
  }
  ngOnInit(): void {
   
  }
  getFoodList(){
    this.foodListService.getfoodList().subscribe(data=>{
      console.log(data);
      this.foodList = data;
    });
  };
  Ondelete(id:number){
    this.foodListService.deletefoodList(id).subscribe(res=>{
      console.log(res);
      this.getFoodList();
    });
  };
getData(id:any){

  this.foodid=id;
this.foodListService.getfoodById(id).subscribe(data=>{
  console.log(data);
  this.editFood.controls['foodId'].setValue(data['foodId']);
  this.editFood.controls['foodName'].setValue(data['foodName']);
  this.editFood.controls['foodprice'].setValue(data['foodprice']);
})
}

Onupdate(){
  var id = this.foodid;
  var foodlist = this.editFood.value;
  this.foodListService.updatefoodList(id,foodlist).subscribe(res=>{
if(res){
  this.getFoodList();
}
  })
}
addRoute(){
  this.router.navigate(['addFood'])
}
back() {
  this.router.navigate(['adminHome'])
}
 };


