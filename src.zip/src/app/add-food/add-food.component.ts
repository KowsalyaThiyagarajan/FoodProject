import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FoodList } from '../food-list';
import { ListfoodComponent } from '../listfood/listfood.component';
import { FoodlistService } from '../service/foodlist.service';

@Component({
  selector: 'app-add-food',
  templateUrl: './add-food.component.html',
  styleUrls: ['./add-food.component.css']
})
export class AddFoodComponent {
  food:FoodList=new FoodList();
  constructor(protected foodservice:FoodlistService,
    private router:Router){}
  ngOnInit(): void {
      
    }
  
    savefood()
    {
      this.foodservice.createFood(this.food).subscribe((data:any)=>
      {
         console.log(data);
       
      },
      (error:any)=>console.log(error));
      }
     
      onSubmit()
      {
        console.log(this.food);
        this.savefood();
        this.router.navigate(['food'])
      }
      back() {
        this.router.navigate(['adminHome'])
      }
  
}
