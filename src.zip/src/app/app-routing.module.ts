import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { FirstpageComponentComponent } from './firstpage-component/firstpage-component.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { MenuComponent } from './menu/menu.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms';
import { OrderComponent } from './order/order.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserListComponent } from './user-list/user-list.component';
import { ListfoodComponent } from './listfood/listfood.component';
import { AddFoodComponent } from './add-food/add-food.component';

const routes: Routes = [
  {
    path:'',
    component:FirstpageComponentComponent
  },
  {
    path:'login',
    component:LoginComponentComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'homepage',
    component:HomePageComponent
  },
  {
    path:'aboutUs',
    component:AboutUsComponent
  },
  {
    path:'gallery',
    component:GalleryComponent
  },
  {
    path:'contact',
    component:ContactComponent
  },
  {
  path:'menu',
  component:MenuComponent
  },
  {
    path:'orderDetails',
    component:OrderComponent
  },
  {
    path:'payment',
    component:PaymentComponent
  },
  {
    path:'adminHome',
    component:AdminhomeComponent
  },
  {
    path:'user',
    component:UserListComponent
  },
  {
    path:'food',
    component:ListfoodComponent
  },
  {
    path:'addFood',
    component:AddFoodComponent
  }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
