import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FoodList } from '../food-list';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FoodlistService {
  private baseURL="http://localhost:8083/api/v1/foodlist"
  constructor(private httpClient:HttpClient) { }
  createFood(food:FoodList):Observable<Object>
  {
    return this.httpClient.post(`${this.baseURL}/${'save'}`,food)
  }
  getfoodList():Observable<FoodList>
  {
    return this.httpClient.get<FoodList>(`${this.baseURL}/${'getAll'}`)
  }
  deletefoodList(id:number):Observable<Object>
  {
    return this.httpClient.delete(`${this.baseURL}/${'deleteFood'}/${id}`);
  }
  updatefoodList(id:number,foodlist:FoodList):Observable<Object>
  {
    return this.httpClient.put(`${this.baseURL}/${'update'}/${id}`,foodlist);
  }
  getfoodById(id:any):Observable<Object>{
return this.httpClient.get(`${this.baseURL}/${id}`)
  }
}
