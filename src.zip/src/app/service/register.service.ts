import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private baseURL="http://localhost:8083/api/v1/customer"
  constructor(private httpClient:HttpClient) { }
  createRegister(data:any):Observable<Object> //observable --> it will observe the data util the response given by the backend and it will throw to ts file 
  {
    return this.httpClient.post(`${this.baseURL}/${'save'}`,data)
  }
  checkUser(data:any):Observable<object>
  {
    return this.httpClient.get(`${this.baseURL}/${'username'}/${data}`)
  }
}