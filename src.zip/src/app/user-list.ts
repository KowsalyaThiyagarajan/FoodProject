export class UserList {
    cId!:number;
    firstname!:string;
    lastname!:string;
    username!:string;
    password!:string;
    email!:string;
    phoneNo!:string;
    location!:string
}
