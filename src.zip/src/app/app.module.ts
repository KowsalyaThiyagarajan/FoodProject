import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { FirstpageComponentComponent } from './firstpage-component/firstpage-component.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { HomePageComponent } from './home-page/home-page.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ContactComponent } from './contact/contact.component';
import { MenuComponent } from './menu/menu.component';
import { HttpClientModule }from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { OrderComponent } from './order/order.component';
import { PaymentComponent } from './payment/payment.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserListComponent } from './user-list/user-list.component';
import { ListfoodComponent } from './listfood/listfood.component';
import { AddFoodComponent } from './add-food/add-food.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponentComponent,
    FirstpageComponentComponent,
    AboutUsComponent,
    HomePageComponent,
    GalleryComponent,
    ContactComponent,
    MenuComponent,
    RegisterComponent,
    OrderComponent,
    PaymentComponent,
    AdminhomeComponent,
    UserListComponent,
    ListfoodComponent,
    AddFoodComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
